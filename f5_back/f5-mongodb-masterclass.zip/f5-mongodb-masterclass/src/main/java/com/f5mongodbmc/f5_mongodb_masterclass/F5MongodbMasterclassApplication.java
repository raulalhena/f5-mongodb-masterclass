package com.f5mongodbmc.f5_mongodb_masterclass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class F5MongodbMasterclassApplication {

	public static void main(String[] args) {
		SpringApplication.run(F5MongodbMasterclassApplication.class, args);
	}

}
