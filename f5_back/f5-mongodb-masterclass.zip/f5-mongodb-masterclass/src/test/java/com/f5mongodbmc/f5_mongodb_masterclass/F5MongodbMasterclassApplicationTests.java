package com.f5mongodbmc.f5_mongodb_masterclass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class F5MongodbMasterclassApplicationTests {

	@Test
	void contextLoads() {
	}

}
